import os
import zipfile
import urllib.request

ASSETS_ZIP_URL = "https://github.com/Catter-see-tinh/Game/raw/refs/heads/main/pygame.zip"
ZIP_NAME = "pygame.zip"
REQUIRED_PATHS = [
    "sprites.py",
    "map/mymap.tmx",
    "nhanvat/???/???.png"
]

print("Đang kiểm tra dữ liệu...")
def check_files():
    for path in REQUIRED_PATHS:
        if not os.path.exists(path):
            return False
    return True
    
def download_zip():
    print("[DOWNLOAD] Đang tải assets.zip...")
    urllib.request.urlretrieve(ASSETS_ZIP_URL, ZIP_NAME)
def extract_zip():
    print("Đang giải nén...")
    with zipfile.ZipFile("pygame.zip", "r") as z:
        z.extractall(".")
        print("Tải thành công")
def cleanup_zip():
    if os.path.exists(pygame.zip):
        os.remove(pygame.zip)

def run():
    if check_files():
        return
    download_zip()
    extract_zip()
    cleanup_zip()
    print("Hoàn tất  dữ liệu")