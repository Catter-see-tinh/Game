import os
import zipfile
import urllib.request

ASSETS_ZIP_URL = "https://github.com/Catter-see-tinh/Game/raw/refs/heads/main/pygame.zip"
ZIP_NAME = "pygame.zip"
REQUIRED_PATHS = [
    "sprites.py",
    "mapsprite.py",
    "map/mymap.tmx",
    "map/Rules/AutoTreeRule.tmx",
    "map/rules.txt",
    "map/Tilesets/Tile_System_48x48.tsx",
    "map/Tilesets/Tile_System_48x48.png",
    "map/Tilesets/TileAuto_Ground_01.png",
    "map/Tilesets/TileAuto_Ground_01_Nature.tsx",
    "map/Tilesets/Tileset_Regular_03_Wilderness.tsx",
    "map/Tilesets/Tileset_Regular_03_Wilderness.png",
    "nhanvat/???/???.png"
]

print("Đang kiểm tra dữ liệu...")
def check_files():
    for path in REQUIRED_PATHS:
        if not os.path.exists(path):
            return False
    return True
    
def download_zip():
    print("[DOWNLOAD] Đang tải assets.zip...")
    urllib.request.urlretrieve(ASSETS_ZIP_URL, ZIP_NAME)
def extract_zip():
    print("Đang giải nén...")
    with zipfile.ZipFile("pygame.zip", "r") as z:
        z.extractall(".")
        print("Tải thành công")
def cleanup_zip():
    if os.path.exists(ZIP_NAME):
        os.remove(ZIP_NAME)

def run():
    if check_files():
        return
    download_zip()
    extract_zip()
    cleanup_zip()
    print("Hoàn tất  dữ liệu")