<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Tile_System_48x48" tilewidth="48" tileheight="48" tilecount="441" columns="21">
 <image source="Tile_System_48x48.png" width="1008" height="1008"/>
 <tile id="21">
  <properties>
   <property name="collision" value="full"/>
  </properties>
 </tile>
 <tile id="22">
  <properties>
   <property name="arrowImpassable" value="left &amp; down &amp; right"/>
  </properties>
 </tile>
 <tile id="23">
  <properties>
   <property name="arrowImpassable" value="left &amp; up &amp; right"/>
  </properties>
 </tile>
 <tile id="24">
  <properties>
   <property name="arrowImpassable" value="up &amp; right &amp; down"/>
  </properties>
 </tile>
 <tile id="25">
  <properties>
   <property name="arrowImpassable" value="up &amp; left &amp; down"/>
  </properties>
 </tile>
 <tile id="27">
  <properties>
   <property name="ladder" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="28">
  <properties>
   <property name="bush" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="29">
  <properties>
   <property name="counter" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="30">
  <properties>
   <property name="damage" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="42">
  <properties>
   <property name="arrowImpassable" value="down &amp; right"/>
  </properties>
 </tile>
 <tile id="43">
  <properties>
   <property name="arrowImpassable" value="down &amp; left"/>
  </properties>
 </tile>
 <tile id="44">
  <properties>
   <property name="arrowImpassable" value="up &amp; left"/>
  </properties>
 </tile>
 <tile id="45">
  <properties>
   <property name="arrowImpassable" value="up &amp; right"/>
  </properties>
 </tile>
 <tile id="46">
  <properties>
   <property name="arrowImpassable" value="left &amp; right"/>
  </properties>
 </tile>
 <tile id="63">
  <properties>
   <property name="arrowImpassable" value="up &amp; down"/>
  </properties>
 </tile>
 <tile id="64">
  <properties>
   <property name="arrowImpassable" value="up"/>
  </properties>
 </tile>
 <tile id="65">
  <properties>
   <property name="arrowImpassable" value="down"/>
  </properties>
 </tile>
 <tile id="66">
  <properties>
   <property name="arrowImpassable" value="right"/>
  </properties>
 </tile>
 <tile id="67">
  <properties>
   <property name="arrowImpassable" value="left"/>
  </properties>
 </tile>
 <tile id="84">
  <properties>
   <property name="toLevel" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="85">
  <properties>
   <property name="toLevel" type="int" value="1"/>
  </properties>
 </tile>
 <tile id="86">
  <properties>
   <property name="toLevel" type="int" value="2"/>
  </properties>
 </tile>
 <tile id="87">
  <properties>
   <property name="toLevel" type="int" value="3"/>
  </properties>
 </tile>
 <tile id="126">
  <properties>
   <property name="regionId" type="int" value="1"/>
  </properties>
 </tile>
 <tile id="127">
  <properties>
   <property name="regionId" type="int" value="2"/>
  </properties>
 </tile>
 <tile id="128">
  <properties>
   <property name="regionId" type="int" value="3"/>
  </properties>
 </tile>
 <tile id="129">
  <properties>
   <property name="regionId" type="int" value="4"/>
  </properties>
 </tile>
 <tile id="130">
  <properties>
   <property name="regionId" type="int" value="5"/>
  </properties>
 </tile>
 <tile id="131">
  <properties>
   <property name="regionId" type="int" value="6"/>
  </properties>
 </tile>
 <tile id="132">
  <properties>
   <property name="regionId" type="int" value="7"/>
  </properties>
 </tile>
 <tile id="133">
  <properties>
   <property name="regionId" type="int" value="8"/>
  </properties>
 </tile>
 <tile id="134">
  <properties>
   <property name="regionId" type="int" value="9"/>
  </properties>
 </tile>
 <tile id="135">
  <properties>
   <property name="regionId" type="int" value="10"/>
  </properties>
 </tile>
 <tile id="137">
  <properties>
   <property name="terrainTag" type="int" value="1"/>
  </properties>
 </tile>
 <tile id="138">
  <properties>
   <property name="terrainTag" type="int" value="2"/>
  </properties>
 </tile>
 <tile id="139">
  <properties>
   <property name="terrainTag" type="int" value="3"/>
  </properties>
 </tile>
 <tile id="140">
  <properties>
   <property name="terrainTag" type="int" value="4"/>
  </properties>
 </tile>
 <tile id="141">
  <properties>
   <property name="terrainTag" type="int" value="5"/>
  </properties>
 </tile>
 <tile id="142">
  <properties>
   <property name="terrainTag" type="int" value="6"/>
  </properties>
 </tile>
 <tile id="143">
  <properties>
   <property name="terrainTag" type="int" value="7"/>
  </properties>
 </tile>
 <tile id="144">
  <properties>
   <property name="terrainTag" type="int" value="8"/>
  </properties>
 </tile>
 <tile id="145">
  <properties>
   <property name="terrainTag" type="int" value="9"/>
  </properties>
 </tile>
 <tile id="146">
  <properties>
   <property name="terrainTag" type="int" value="10"/>
  </properties>
 </tile>
 <tile id="147">
  <properties>
   <property name="regionId" type="int" value="11"/>
  </properties>
 </tile>
 <tile id="148">
  <properties>
   <property name="regionId" type="int" value="12"/>
  </properties>
 </tile>
 <tile id="149">
  <properties>
   <property name="regionId" type="int" value="13"/>
  </properties>
 </tile>
 <tile id="150">
  <properties>
   <property name="regionId" type="int" value="14"/>
  </properties>
 </tile>
 <tile id="151">
  <properties>
   <property name="regionId" type="int" value="15"/>
  </properties>
 </tile>
 <tile id="152">
  <properties>
   <property name="regionId" type="int" value="16"/>
  </properties>
 </tile>
 <tile id="153">
  <properties>
   <property name="regionId" type="int" value="17"/>
  </properties>
 </tile>
 <tile id="154">
  <properties>
   <property name="regionId" type="int" value="18"/>
  </properties>
 </tile>
 <tile id="155">
  <properties>
   <property name="regionId" type="int" value="19"/>
  </properties>
 </tile>
 <tile id="156">
  <properties>
   <property name="regionId" type="int" value="20"/>
  </properties>
 </tile>
 <tile id="158">
  <properties>
   <property name="terrainTag" type="int" value="11"/>
  </properties>
 </tile>
 <tile id="159">
  <properties>
   <property name="terrainTag" type="int" value="12"/>
  </properties>
 </tile>
 <tile id="160">
  <properties>
   <property name="terrainTag" type="int" value="13"/>
  </properties>
 </tile>
 <tile id="161">
  <properties>
   <property name="terrainTag" type="int" value="14"/>
  </properties>
 </tile>
 <tile id="162">
  <properties>
   <property name="terrainTag" type="int" value="15"/>
  </properties>
 </tile>
 <tile id="163">
  <properties>
   <property name="terrainTag" type="int" value="16"/>
  </properties>
 </tile>
 <tile id="164">
  <properties>
   <property name="terrainTag" type="int" value="17"/>
  </properties>
 </tile>
 <tile id="165">
  <properties>
   <property name="terrainTag" type="int" value="18"/>
  </properties>
 </tile>
 <tile id="166">
  <properties>
   <property name="terrainTag" type="int" value="19"/>
  </properties>
 </tile>
 <tile id="167">
  <properties>
   <property name="terrainTag" type="int" value="20"/>
  </properties>
 </tile>
 <tile id="168">
  <properties>
   <property name="regionId" type="int" value="21"/>
  </properties>
 </tile>
 <tile id="169">
  <properties>
   <property name="regionId" type="int" value="22"/>
  </properties>
 </tile>
 <tile id="170">
  <properties>
   <property name="regionId" type="int" value="23"/>
  </properties>
 </tile>
 <tile id="171">
  <properties>
   <property name="regionId" type="int" value="24"/>
  </properties>
 </tile>
 <tile id="172">
  <properties>
   <property name="regionId" type="int" value="25"/>
  </properties>
 </tile>
 <tile id="173">
  <properties>
   <property name="regionId" type="int" value="26"/>
  </properties>
 </tile>
 <tile id="174">
  <properties>
   <property name="regionId" type="int" value="27"/>
  </properties>
 </tile>
 <tile id="175">
  <properties>
   <property name="regionId" type="int" value="28"/>
  </properties>
 </tile>
 <tile id="176">
  <properties>
   <property name="regionId" type="int" value="29"/>
  </properties>
 </tile>
 <tile id="177">
  <properties>
   <property name="regionId" type="int" value="30"/>
  </properties>
 </tile>
 <tile id="179">
  <properties>
   <property name="terrainTag" type="int" value="21"/>
  </properties>
 </tile>
 <tile id="180">
  <properties>
   <property name="terrainTag" type="int" value="22"/>
  </properties>
 </tile>
 <tile id="181">
  <properties>
   <property name="terrainTag" type="int" value="23"/>
  </properties>
 </tile>
 <tile id="182">
  <properties>
   <property name="terrainTag" type="int" value="24"/>
  </properties>
 </tile>
 <tile id="183">
  <properties>
   <property name="terrainTag" type="int" value="25"/>
  </properties>
 </tile>
 <tile id="184">
  <properties>
   <property name="terrainTag" type="int" value="26"/>
  </properties>
 </tile>
 <tile id="185">
  <properties>
   <property name="terrainTag" type="int" value="27"/>
  </properties>
 </tile>
 <tile id="186">
  <properties>
   <property name="terrainTag" type="int" value="28"/>
  </properties>
 </tile>
 <tile id="187">
  <properties>
   <property name="terrainTag" type="int" value="29"/>
  </properties>
 </tile>
 <tile id="188">
  <properties>
   <property name="terrainTag" type="int" value="30"/>
  </properties>
 </tile>
 <tile id="189">
  <properties>
   <property name="regionId" type="int" value="31"/>
  </properties>
 </tile>
 <tile id="190">
  <properties>
   <property name="regionId" type="int" value="32"/>
  </properties>
 </tile>
 <tile id="191">
  <properties>
   <property name="regionId" type="int" value="33"/>
  </properties>
 </tile>
 <tile id="192">
  <properties>
   <property name="regionId" type="int" value="34"/>
  </properties>
 </tile>
 <tile id="193">
  <properties>
   <property name="regionId" type="int" value="35"/>
  </properties>
 </tile>
 <tile id="194">
  <properties>
   <property name="regionId" type="int" value="36"/>
  </properties>
 </tile>
 <tile id="195">
  <properties>
   <property name="regionId" type="int" value="37"/>
  </properties>
 </tile>
 <tile id="196">
  <properties>
   <property name="regionId" type="int" value="38"/>
  </properties>
 </tile>
 <tile id="197">
  <properties>
   <property name="regionId" type="int" value="39"/>
  </properties>
 </tile>
 <tile id="198">
  <properties>
   <property name="regionId" type="int" value="40"/>
  </properties>
 </tile>
 <tile id="200">
  <properties>
   <property name="terrainTag" type="int" value="31"/>
  </properties>
 </tile>
 <tile id="201">
  <properties>
   <property name="terrainTag" type="int" value="32"/>
  </properties>
 </tile>
 <tile id="202">
  <properties>
   <property name="terrainTag" type="int" value="33"/>
  </properties>
 </tile>
 <tile id="203">
  <properties>
   <property name="terrainTag" type="int" value="34"/>
  </properties>
 </tile>
 <tile id="204">
  <properties>
   <property name="terrainTag" type="int" value="35"/>
  </properties>
 </tile>
 <tile id="205">
  <properties>
   <property name="terrainTag" type="int" value="36"/>
  </properties>
 </tile>
 <tile id="206">
  <properties>
   <property name="terrainTag" type="int" value="37"/>
  </properties>
 </tile>
 <tile id="207">
  <properties>
   <property name="terrainTag" type="int" value="38"/>
  </properties>
 </tile>
 <tile id="208">
  <properties>
   <property name="terrainTag" type="int" value="39"/>
  </properties>
 </tile>
 <tile id="209">
  <properties>
   <property name="terrainTag" type="int" value="40"/>
  </properties>
 </tile>
 <tile id="210">
  <properties>
   <property name="regionId" type="int" value="41"/>
  </properties>
 </tile>
 <tile id="211">
  <properties>
   <property name="regionId" type="int" value="42"/>
  </properties>
 </tile>
 <tile id="212">
  <properties>
   <property name="regionId" type="int" value="43"/>
  </properties>
 </tile>
 <tile id="213">
  <properties>
   <property name="regionId" type="int" value="44"/>
  </properties>
 </tile>
 <tile id="214">
  <properties>
   <property name="regionId" type="int" value="45"/>
  </properties>
 </tile>
 <tile id="215">
  <properties>
   <property name="regionId" type="int" value="46"/>
  </properties>
 </tile>
 <tile id="216">
  <properties>
   <property name="regionId" type="int" value="47"/>
  </properties>
 </tile>
 <tile id="217">
  <properties>
   <property name="regionId" type="int" value="48"/>
  </properties>
 </tile>
 <tile id="218">
  <properties>
   <property name="regionId" type="int" value="49"/>
  </properties>
 </tile>
 <tile id="219">
  <properties>
   <property name="regionId" type="int" value="50"/>
  </properties>
 </tile>
 <tile id="221">
  <properties>
   <property name="terrainTag" type="int" value="41"/>
  </properties>
 </tile>
 <tile id="222">
  <properties>
   <property name="terrainTag" type="int" value="42"/>
  </properties>
 </tile>
 <tile id="223">
  <properties>
   <property name="terrainTag" type="int" value="43"/>
  </properties>
 </tile>
 <tile id="224">
  <properties>
   <property name="terrainTag" type="int" value="44"/>
  </properties>
 </tile>
 <tile id="225">
  <properties>
   <property name="terrainTag" type="int" value="45"/>
  </properties>
 </tile>
 <tile id="226">
  <properties>
   <property name="terrainTag" type="int" value="46"/>
  </properties>
 </tile>
 <tile id="227">
  <properties>
   <property name="terrainTag" type="int" value="47"/>
  </properties>
 </tile>
 <tile id="228">
  <properties>
   <property name="terrainTag" type="int" value="48"/>
  </properties>
 </tile>
 <tile id="229">
  <properties>
   <property name="terrainTag" type="int" value="49"/>
  </properties>
 </tile>
 <tile id="230">
  <properties>
   <property name="terrainTag" type="int" value="50"/>
  </properties>
 </tile>
 <tile id="231">
  <properties>
   <property name="regionId" type="int" value="51"/>
  </properties>
 </tile>
 <tile id="232">
  <properties>
   <property name="regionId" type="int" value="52"/>
  </properties>
 </tile>
 <tile id="233">
  <properties>
   <property name="regionId" type="int" value="53"/>
  </properties>
 </tile>
 <tile id="234">
  <properties>
   <property name="regionId" type="int" value="54"/>
  </properties>
 </tile>
 <tile id="235">
  <properties>
   <property name="regionId" type="int" value="55"/>
  </properties>
 </tile>
 <tile id="236">
  <properties>
   <property name="regionId" type="int" value="56"/>
  </properties>
 </tile>
 <tile id="237">
  <properties>
   <property name="regionId" type="int" value="57"/>
  </properties>
 </tile>
 <tile id="238">
  <properties>
   <property name="regionId" type="int" value="58"/>
  </properties>
 </tile>
 <tile id="239">
  <properties>
   <property name="regionId" type="int" value="59"/>
  </properties>
 </tile>
 <tile id="240">
  <properties>
   <property name="regionId" type="int" value="60"/>
  </properties>
 </tile>
 <tile id="242">
  <properties>
   <property name="terrainTag" type="int" value="51"/>
  </properties>
 </tile>
 <tile id="243">
  <properties>
   <property name="terrainTag" type="int" value="52"/>
  </properties>
 </tile>
 <tile id="244">
  <properties>
   <property name="terrainTag" type="int" value="53"/>
  </properties>
 </tile>
 <tile id="245">
  <properties>
   <property name="terrainTag" type="int" value="54"/>
  </properties>
 </tile>
 <tile id="246">
  <properties>
   <property name="terrainTag" type="int" value="55"/>
  </properties>
 </tile>
 <tile id="247">
  <properties>
   <property name="terrainTag" type="int" value="56"/>
  </properties>
 </tile>
 <tile id="248">
  <properties>
   <property name="terrainTag" type="int" value="57"/>
  </properties>
 </tile>
 <tile id="249">
  <properties>
   <property name="terrainTag" type="int" value="58"/>
  </properties>
 </tile>
 <tile id="250">
  <properties>
   <property name="terrainTag" type="int" value="59"/>
  </properties>
 </tile>
 <tile id="251">
  <properties>
   <property name="terrainTag" type="int" value="60"/>
  </properties>
 </tile>
 <tile id="252">
  <properties>
   <property name="regionId" type="int" value="61"/>
  </properties>
 </tile>
 <tile id="253">
  <properties>
   <property name="regionId" type="int" value="62"/>
  </properties>
 </tile>
 <tile id="254">
  <properties>
   <property name="regionId" type="int" value="63"/>
  </properties>
 </tile>
 <tile id="255">
  <properties>
   <property name="regionId" type="int" value="64"/>
  </properties>
 </tile>
 <tile id="256">
  <properties>
   <property name="regionId" type="int" value="65"/>
  </properties>
 </tile>
 <tile id="257">
  <properties>
   <property name="regionId" type="int" value="66"/>
  </properties>
 </tile>
 <tile id="258">
  <properties>
   <property name="regionId" type="int" value="67"/>
  </properties>
 </tile>
 <tile id="259">
  <properties>
   <property name="regionId" type="int" value="68"/>
  </properties>
 </tile>
 <tile id="260">
  <properties>
   <property name="regionId" type="int" value="69"/>
  </properties>
 </tile>
 <tile id="261">
  <properties>
   <property name="regionId" type="int" value="70"/>
  </properties>
 </tile>
 <tile id="263">
  <properties>
   <property name="terrainTag" type="int" value="61"/>
  </properties>
 </tile>
 <tile id="264">
  <properties>
   <property name="terrainTag" type="int" value="62"/>
  </properties>
 </tile>
 <tile id="265">
  <properties>
   <property name="terrainTag" type="int" value="63"/>
  </properties>
 </tile>
 <tile id="266">
  <properties>
   <property name="terrainTag" type="int" value="64"/>
  </properties>
 </tile>
 <tile id="267">
  <properties>
   <property name="terrainTag" type="int" value="65"/>
  </properties>
 </tile>
 <tile id="268">
  <properties>
   <property name="terrainTag" type="int" value="66"/>
  </properties>
 </tile>
 <tile id="269">
  <properties>
   <property name="terrainTag" type="int" value="67"/>
  </properties>
 </tile>
 <tile id="270">
  <properties>
   <property name="terrainTag" type="int" value="68"/>
  </properties>
 </tile>
 <tile id="271">
  <properties>
   <property name="terrainTag" type="int" value="69"/>
  </properties>
 </tile>
 <tile id="272">
  <properties>
   <property name="terrainTag" type="int" value="70"/>
  </properties>
 </tile>
 <tile id="273">
  <properties>
   <property name="regionId" type="int" value="71"/>
  </properties>
 </tile>
 <tile id="274">
  <properties>
   <property name="regionId" type="int" value="72"/>
  </properties>
 </tile>
 <tile id="275">
  <properties>
   <property name="regionId" type="int" value="73"/>
  </properties>
 </tile>
 <tile id="276">
  <properties>
   <property name="regionId" type="int" value="74"/>
  </properties>
 </tile>
 <tile id="277">
  <properties>
   <property name="regionId" type="int" value="75"/>
  </properties>
 </tile>
 <tile id="278">
  <properties>
   <property name="regionId" type="int" value="76"/>
  </properties>
 </tile>
 <tile id="279">
  <properties>
   <property name="regionId" type="int" value="77"/>
  </properties>
 </tile>
 <tile id="280">
  <properties>
   <property name="regionId" type="int" value="78"/>
  </properties>
 </tile>
 <tile id="281">
  <properties>
   <property name="regionId" type="int" value="79"/>
  </properties>
 </tile>
 <tile id="282">
  <properties>
   <property name="regionId" type="int" value="80"/>
  </properties>
 </tile>
 <tile id="284">
  <properties>
   <property name="terrainTag" type="int" value="71"/>
  </properties>
 </tile>
 <tile id="285">
  <properties>
   <property name="terrainTag" type="int" value="72"/>
  </properties>
 </tile>
 <tile id="286">
  <properties>
   <property name="terrainTag" type="int" value="73"/>
  </properties>
 </tile>
 <tile id="287">
  <properties>
   <property name="terrainTag" type="int" value="74"/>
  </properties>
 </tile>
 <tile id="288">
  <properties>
   <property name="terrainTag" type="int" value="75"/>
  </properties>
 </tile>
 <tile id="289">
  <properties>
   <property name="terrainTag" type="int" value="76"/>
  </properties>
 </tile>
 <tile id="290">
  <properties>
   <property name="terrainTag" type="int" value="77"/>
  </properties>
 </tile>
 <tile id="291">
  <properties>
   <property name="terrainTag" type="int" value="78"/>
  </properties>
 </tile>
 <tile id="292">
  <properties>
   <property name="terrainTag" type="int" value="79"/>
  </properties>
 </tile>
 <tile id="293">
  <properties>
   <property name="terrainTag" type="int" value="80"/>
  </properties>
 </tile>
 <tile id="294">
  <properties>
   <property name="regionId" type="int" value="81"/>
  </properties>
 </tile>
 <tile id="295">
  <properties>
   <property name="regionId" type="int" value="82"/>
  </properties>
 </tile>
 <tile id="296">
  <properties>
   <property name="regionId" type="int" value="83"/>
  </properties>
 </tile>
 <tile id="297">
  <properties>
   <property name="regionId" type="int" value="84"/>
  </properties>
 </tile>
 <tile id="298">
  <properties>
   <property name="regionId" type="int" value="85"/>
  </properties>
 </tile>
 <tile id="299">
  <properties>
   <property name="regionId" type="int" value="86"/>
  </properties>
 </tile>
 <tile id="300">
  <properties>
   <property name="regionId" type="int" value="87"/>
  </properties>
 </tile>
 <tile id="301">
  <properties>
   <property name="regionId" type="int" value="88"/>
  </properties>
 </tile>
 <tile id="302">
  <properties>
   <property name="regionId" type="int" value="89"/>
  </properties>
 </tile>
 <tile id="303">
  <properties>
   <property name="regionId" type="int" value="90"/>
  </properties>
 </tile>
 <tile id="305">
  <properties>
   <property name="terrainTag" type="int" value="81"/>
  </properties>
 </tile>
 <tile id="306">
  <properties>
   <property name="terrainTag" type="int" value="82"/>
  </properties>
 </tile>
 <tile id="307">
  <properties>
   <property name="terrainTag" type="int" value="83"/>
  </properties>
 </tile>
 <tile id="308">
  <properties>
   <property name="terrainTag" type="int" value="84"/>
  </properties>
 </tile>
 <tile id="309">
  <properties>
   <property name="terrainTag" type="int" value="85"/>
  </properties>
 </tile>
 <tile id="310">
  <properties>
   <property name="terrainTag" type="int" value="86"/>
  </properties>
 </tile>
 <tile id="311">
  <properties>
   <property name="terrainTag" type="int" value="87"/>
  </properties>
 </tile>
 <tile id="312">
  <properties>
   <property name="terrainTag" type="int" value="88"/>
  </properties>
 </tile>
 <tile id="313">
  <properties>
   <property name="terrainTag" type="int" value="89"/>
  </properties>
 </tile>
 <tile id="314">
  <properties>
   <property name="terrainTag" type="int" value="90"/>
  </properties>
 </tile>
 <tile id="315">
  <properties>
   <property name="regionId" type="int" value="91"/>
  </properties>
 </tile>
 <tile id="316">
  <properties>
   <property name="regionId" type="int" value="92"/>
  </properties>
 </tile>
 <tile id="317">
  <properties>
   <property name="regionId" type="int" value="93"/>
  </properties>
 </tile>
 <tile id="318">
  <properties>
   <property name="regionId" type="int" value="94"/>
  </properties>
 </tile>
 <tile id="319">
  <properties>
   <property name="regionId" type="int" value="95"/>
  </properties>
 </tile>
 <tile id="320">
  <properties>
   <property name="regionId" type="int" value="96"/>
  </properties>
 </tile>
 <tile id="321">
  <properties>
   <property name="regionId" type="int" value="97"/>
  </properties>
 </tile>
 <tile id="322">
  <properties>
   <property name="regionId" type="int" value="98"/>
  </properties>
 </tile>
 <tile id="323">
  <properties>
   <property name="regionId" type="int" value="99"/>
  </properties>
 </tile>
 <tile id="324">
  <properties>
   <property name="regionId" type="int" value="100"/>
  </properties>
 </tile>
 <tile id="326">
  <properties>
   <property name="terrainTag" type="int" value="91"/>
  </properties>
 </tile>
 <tile id="327">
  <properties>
   <property name="terrainTag" type="int" value="92"/>
  </properties>
 </tile>
 <tile id="328">
  <properties>
   <property name="terrainTag" type="int" value="93"/>
  </properties>
 </tile>
 <tile id="329">
  <properties>
   <property name="terrainTag" type="int" value="94"/>
  </properties>
 </tile>
 <tile id="330">
  <properties>
   <property name="terrainTag" type="int" value="95"/>
  </properties>
 </tile>
 <tile id="331">
  <properties>
   <property name="terrainTag" type="int" value="96"/>
  </properties>
 </tile>
 <tile id="332">
  <properties>
   <property name="terrainTag" type="int" value="97"/>
  </properties>
 </tile>
 <tile id="333">
  <properties>
   <property name="terrainTag" type="int" value="98"/>
  </properties>
 </tile>
 <tile id="334">
  <properties>
   <property name="terrainTag" type="int" value="99"/>
  </properties>
 </tile>
 <tile id="335">
  <properties>
   <property name="terrainTag" type="int" value="100"/>
  </properties>
 </tile>
 <tile id="336">
  <properties>
   <property name="regionId" type="int" value="101"/>
  </properties>
 </tile>
 <tile id="337">
  <properties>
   <property name="regionId" type="int" value="102"/>
  </properties>
 </tile>
 <tile id="338">
  <properties>
   <property name="regionId" type="int" value="103"/>
  </properties>
 </tile>
 <tile id="339">
  <properties>
   <property name="regionId" type="int" value="104"/>
  </properties>
 </tile>
 <tile id="340">
  <properties>
   <property name="regionId" type="int" value="105"/>
  </properties>
 </tile>
 <tile id="341">
  <properties>
   <property name="regionId" type="int" value="106"/>
  </properties>
 </tile>
 <tile id="342">
  <properties>
   <property name="regionId" type="int" value="107"/>
  </properties>
 </tile>
 <tile id="343">
  <properties>
   <property name="regionId" type="int" value="108"/>
  </properties>
 </tile>
 <tile id="344">
  <properties>
   <property name="regionId" type="int" value="109"/>
  </properties>
 </tile>
 <tile id="345">
  <properties>
   <property name="regionId" type="int" value="110"/>
  </properties>
 </tile>
 <tile id="347">
  <properties>
   <property name="terrainTag" type="int" value="101"/>
  </properties>
 </tile>
 <tile id="348">
  <properties>
   <property name="terrainTag" type="int" value="102"/>
  </properties>
 </tile>
 <tile id="349">
  <properties>
   <property name="terrainTag" type="int" value="103"/>
  </properties>
 </tile>
 <tile id="350">
  <properties>
   <property name="terrainTag" type="int" value="104"/>
  </properties>
 </tile>
 <tile id="351">
  <properties>
   <property name="terrainTag" type="int" value="105"/>
  </properties>
 </tile>
 <tile id="352">
  <properties>
   <property name="terrainTag" type="int" value="106"/>
  </properties>
 </tile>
 <tile id="353">
  <properties>
   <property name="terrainTag" type="int" value="107"/>
  </properties>
 </tile>
 <tile id="354">
  <properties>
   <property name="terrainTag" type="int" value="108"/>
  </properties>
 </tile>
 <tile id="355">
  <properties>
   <property name="terrainTag" type="int" value="109"/>
  </properties>
 </tile>
 <tile id="356">
  <properties>
   <property name="terrainTag" type="int" value="110"/>
  </properties>
 </tile>
 <tile id="357">
  <properties>
   <property name="regionId" type="int" value="111"/>
  </properties>
 </tile>
 <tile id="358">
  <properties>
   <property name="regionId" type="int" value="112"/>
  </properties>
 </tile>
 <tile id="359">
  <properties>
   <property name="regionId" type="int" value="113"/>
  </properties>
 </tile>
 <tile id="360">
  <properties>
   <property name="regionId" type="int" value="114"/>
  </properties>
 </tile>
 <tile id="361">
  <properties>
   <property name="regionId" type="int" value="115"/>
  </properties>
 </tile>
 <tile id="362">
  <properties>
   <property name="regionId" type="int" value="116"/>
  </properties>
 </tile>
 <tile id="363">
  <properties>
   <property name="regionId" type="int" value="117"/>
  </properties>
 </tile>
 <tile id="364">
  <properties>
   <property name="regionId" type="int" value="118"/>
  </properties>
 </tile>
 <tile id="365">
  <properties>
   <property name="regionId" type="int" value="119"/>
  </properties>
 </tile>
 <tile id="366">
  <properties>
   <property name="regionId" type="int" value="120"/>
  </properties>
 </tile>
 <tile id="368">
  <properties>
   <property name="terrainTag" type="int" value="111"/>
  </properties>
 </tile>
 <tile id="369">
  <properties>
   <property name="terrainTag" type="int" value="112"/>
  </properties>
 </tile>
 <tile id="370">
  <properties>
   <property name="terrainTag" type="int" value="113"/>
  </properties>
 </tile>
 <tile id="371">
  <properties>
   <property name="terrainTag" type="int" value="114"/>
  </properties>
 </tile>
 <tile id="372">
  <properties>
   <property name="terrainTag" type="int" value="115"/>
  </properties>
 </tile>
 <tile id="373">
  <properties>
   <property name="terrainTag" type="int" value="116"/>
  </properties>
 </tile>
 <tile id="374">
  <properties>
   <property name="terrainTag" type="int" value="117"/>
  </properties>
 </tile>
 <tile id="375">
  <properties>
   <property name="terrainTag" type="int" value="118"/>
  </properties>
 </tile>
 <tile id="376">
  <properties>
   <property name="terrainTag" type="int" value="119"/>
  </properties>
 </tile>
 <tile id="377">
  <properties>
   <property name="terrainTag" type="int" value="120"/>
  </properties>
 </tile>
 <tile id="378">
  <properties>
   <property name="regionId" type="int" value="121"/>
  </properties>
 </tile>
 <tile id="379">
  <properties>
   <property name="regionId" type="int" value="122"/>
  </properties>
 </tile>
 <tile id="380">
  <properties>
   <property name="regionId" type="int" value="123"/>
  </properties>
 </tile>
 <tile id="381">
  <properties>
   <property name="regionId" type="int" value="124"/>
  </properties>
 </tile>
 <tile id="382">
  <properties>
   <property name="regionId" type="int" value="125"/>
  </properties>
 </tile>
 <tile id="383">
  <properties>
   <property name="regionId" type="int" value="126"/>
  </properties>
 </tile>
 <tile id="384">
  <properties>
   <property name="regionId" type="int" value="127"/>
  </properties>
 </tile>
 <tile id="385">
  <properties>
   <property name="regionId" type="int" value="11"/>
  </properties>
 </tile>
 <tile id="386">
  <properties>
   <property name="regionId" type="int" value="11"/>
  </properties>
 </tile>
 <tile id="387">
  <properties>
   <property name="regionId" type="int" value="11"/>
  </properties>
 </tile>
 <tile id="389">
  <properties>
   <property name="terrainTag" type="int" value="121"/>
  </properties>
 </tile>
 <tile id="390">
  <properties>
   <property name="terrainTag" type="int" value="122"/>
  </properties>
 </tile>
 <tile id="391">
  <properties>
   <property name="terrainTag" type="int" value="123"/>
  </properties>
 </tile>
 <tile id="392">
  <properties>
   <property name="terrainTag" type="int" value="124"/>
  </properties>
 </tile>
 <tile id="393">
  <properties>
   <property name="terrainTag" type="int" value="125"/>
  </properties>
 </tile>
 <tile id="394">
  <properties>
   <property name="terrainTag" type="int" value="126"/>
  </properties>
 </tile>
 <tile id="395">
  <properties>
   <property name="terrainTag" type="int" value="127"/>
  </properties>
 </tile>
</tileset>
