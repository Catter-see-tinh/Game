<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="03Wilds" tilewidth="48" tileheight="48" tilecount="441" columns="21">
 <image source="Tileset_Regular_03_Wilderness.png" width="1008" height="1008"/>
</tileset>
