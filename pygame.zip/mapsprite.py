import pygame

class Mapsprite(pygame.sprite.Group):
    def __init__(self):
        super().__init__()
        self.offset = pygame.Vector2()
        
    def draw(self, surface, player_pos):
        self.surf = surface
        self.pos = player_pos
        
        self.offset.x = self.pos[0] - 1460/2
        self.offset.y = self.pos[1] - 660/2
        
        for sprite in self:
            self.surf.blit(sprite.image, sprite.rect.topleft - self.offset)
        